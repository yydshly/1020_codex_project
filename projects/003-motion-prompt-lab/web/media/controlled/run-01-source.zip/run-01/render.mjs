import fs from 'node:fs';
import path from 'node:path';
import {createRequire} from 'node:module';
import {spawn} from 'node:child_process';
import {once} from 'node:events';
const require=createRequire('F:/codex_project/1020_codex_project/projects/003-motion-prompt-lab/node_modules/_resolver.cjs');
const {createCanvas,GlobalFonts,loadImage}=require('@napi-rs/canvas');
const {Resvg}=require('@resvg/resvg-js');
const ROOT=path.dirname(new URL(import.meta.url).pathname.replace(/^\/([A-Za-z]:)/,'$1'));
process.chdir(ROOT);
GlobalFonts.registerFromPath('../shared/fonts/msyh.ttc','YaHei');GlobalFonts.registerFromPath('../shared/fonts/segoeui.ttf','Segoe');
const timing=JSON.parse(fs.readFileSync('timing.json','utf8'));const W=1280,H=720;
const C={paper:'#f6f5f0',white:'#fffefa',ink:'#263b34',green:'#255746',pale:'#e7ede3',orange:'#ac573b'};
const logo=await loadImage(new Resvg(fs.readFileSync('../shared/captures/source-favicon.svg')).render().asPng());
const canvas=createCanvas(W,H),ctx=canvas.getContext('2d');
const accum=createCanvas(W,H),ac=accum.getContext('2d');
const starts=timing.scene_start_frames, ends=[...starts.slice(1),1200];
const rects=[[720,160,470,390],[286,168,904,422],[90,190,1100,390],[430,174,760,416],[340,176,850,410],[90,190,1100,392],[375,510,530,104]];
const endRects=[[600,142,590,432],[260,156,930,446],[74,180,1132,414],[430,174,760,416],[292,164,898,436],[90,174,1100,424],[360,492,560,124]];
const clamp=x=>Math.max(0,Math.min(1,x));const ease=x=>{x=clamp(x);return x*x*x*(x*(x*6-15)+10)};const lerp=(a,b,t)=>a+(b-a)*t;
function rr(x,y,w,h,r=16,fill=C.white,stroke=null){ctx.beginPath();ctx.roundRect(x,y,w,h,r);if(fill){ctx.fillStyle=fill;ctx.fill()}if(stroke){ctx.strokeStyle=stroke;ctx.lineWidth=1.2;ctx.stroke()}}
function txt(s,x,y,size=24,color=C.ink,weight=400,align='left',family='YaHei'){if(/[\u4e00-\u9fff]/.test(s))family='YaHei';ctx.font=`${weight} ${size}px ${family}`;ctx.fillStyle=color;ctx.textAlign=align;ctx.textBaseline='top';ctx.fillText(s,x,y)}
function line(x1,y1,x2,y2,color=C.green,width=2){ctx.beginPath();ctx.moveTo(x1,y1);ctx.lineTo(x2,y2);ctx.strokeStyle=color;ctx.lineWidth=width;ctx.stroke()}
function pill(s,x,y,w,active=false,size=20){rr(x,y,w,40,8,active?C.green:C.pale);txt(s,x+w/2,y+7,size,active?C.white:C.ink,500,'center')}
function arrow(x,y,w=32){line(x,y,x+w,y,C.green,2);line(x+w-7,y-6,x+w,y);line(x+w-7,y+6,x+w,y)}
function shadowRect(r){ctx.save();ctx.shadowColor='#263b3420';ctx.shadowBlur=30;ctx.shadowOffsetY=12;rr(...r,18,C.white);ctx.restore();rr(...r,18,null,C.pale)}
function fadeText(s,x,y,size,color,a){ctx.save();ctx.globalAlpha=a;txt(s,x,y,size,color);ctx.restore()}
function cursor(x,y,click=0){ctx.save();ctx.translate(x,y);ctx.beginPath();ctx.moveTo(0,0);ctx.lineTo(0,25);ctx.lineTo(7,19);ctx.lineTo(13,31);ctx.lineTo(18,28);ctx.lineTo(12,17);ctx.lineTo(22,17);ctx.closePath();ctx.fillStyle=C.ink;ctx.strokeStyle=C.white;ctx.lineWidth=2;ctx.fill();ctx.stroke();if(click>0){ctx.globalAlpha=1-click;ctx.beginPath();ctx.arc(4,9,10+click*25,0,Math.PI*2);ctx.strokeStyle=C.orange;ctx.lineWidth=3;ctx.stroke()}ctx.restore()}
function mainRect(f){let s=0;for(let i=1;i<starts.length;i++)if(f>=starts[i])s=i;let t=f-starts[s],r;if(s>0&&t<30){let p=ease(t/30);r=rects[s].map((v,i)=>lerp(endRects[s-1][i],v,p))}else{let u=clamp((t-(s?30:0))/(ends[s]-starts[s]-(s?30:0)));let p=.3*u+.7*ease(u);r=rects[s].map((v,i)=>lerp(v,endRects[s][i],p))}return {s,r}}
function outer(s,t){
 if(s===0){txt('收藏之后，',90,226,66,C.ink,600);txt('下一步？',90,312,78,C.green,600);txt('从一个工具，走进一项原理。',94,430,26);txt('Kokoro · 语音合成',94,490,20,C.green);}
 if(s===1){txt('让收藏，成为理解。',90,91,48,C.ink,600);rr(90,182,166,388,12,C.pale);txt('工具研究笔记',108,205,20,C.green,600);['研究总览','能力对照','实验记录'].forEach((v,i)=>txt(v,110,264+i*46,19));line(110,410,234,410,C.green,1);pill('01  Kokoro',102,439,142,true,19);txt('学习路径',110,508,18);}
 if(s===2){txt('文字，怎样变成声音？',90,100,46,C.ink,600);}
 if(s===3){txt('先看懂，',90,238,51,C.ink,600);txt('再下结论。',90,308,51,C.green,600);txt('声音基础',94,420,24,C.green);txt('学习材料展开 →',94,465,22);}
 if(s===4){txt('每一步，',90,250,43,C.ink,600);txt('都有来源。',90,312,43,C.green,600);txt('从解释到代码',94,421,23);}
 if(s===5){txt('用小实验，继续研究。',90,100,46,C.ink,600);}
 if(s===6){ctx.drawImage(logo,90,96,54,54);txt('从收藏，到理解，再到验证。',640,210,31,C.green,400,'center');txt('GitHub 项目研究集',640,279,66,C.ink,600,'center');txt('github.com/yydshly/1020_codex_project',640,385,31,C.green,500,'center','Segoe');}
}
function inner(s,t,r){let [x,y,w,h]=r;let ix=x+32, top=y+94;
 if(s===0){pill('语音合成',ix,top,124,false);txt('一段文字，',ix,top+68,38,C.ink,600);txt('怎样变成声音？',ix,top+118,38,C.ink,600);line(ix,top+189,x+w-32,top+189,C.pale,2);txt('文稿 + 语言 + 音色',ix,top+215,24);pill(t<60?'进入研究 →':'打开研究条目',ix,top+254,210,t>=60,21);let cp=ease(t/60);cursor(lerp(x+w-54,ix+160,cp),lerp(y+h-45,top+278,cp),t>=60&&t<78?(t-60)/18:0);}
 if(s===1){['效果与能力','底层原理','验证计划','来源与版本'].forEach((v,i)=>pill(v,ix+i*204,top,188,i===1&&t>=60,21));txt('一段文字，怎样变成声音？',ix,top+75,35,C.ink,600);if(t<90){rr(ix,top+146,w-64,109,10,C.pale);txt('文稿 + 语言 + 音色',ix+26,top+171,25);arrow(ix+340,top+191,60);txt('语音波形 / WAV',ix+435,top+171,25,C.green,600)}else{['文字转音素','时长与韵律','波形解码'].forEach((label,j)=>{let bw=(w-100)/3;rr(ix+j*(bw+18),top+146,bw,109,10,C.pale);txt(label,ix+16+j*(bw+18),top+171,25,C.ink,600);txt('0'+(j+1),ix+16+j*(bw+18),top+218,18,C.green);if(j<2)arrow(ix+(j+1)*(bw+18)-15,top+195,10)})}txt(t<100?'深入拆解 · 本机效果待验证':'原理入口：发音处理 → 时长与韵律 → 波形解码',ix,top+278,21,C.green);let p=ease(t/60);cursor(lerp(x+w-80,ix+290,p),lerp(y+h-55,top+23,p),t>=60&&t<78?(t-60)/18:0);}
 if(s===2){txt('底层原理',ix,top-8,23,C.green);const labels=['文字转音素','时长与韵律','波形解码'];const sub=['KPipeline.g2p','风格条件 + 音素','音频采样值'];for(let i=0;i<3;i++){let bx=ix+i*350;let p=ease((t-i*42)/90);rr(bx,top+50,326,132,12,p>.5?C.pale:C.paper);txt(String(i+1).padStart(2,'0'),bx+20,top+69,18,C.green,500,'left','Segoe');txt(labels[i],bx+20,top+100,29,C.ink,600);txt(sub[i],bx+20,top+145,18,C.green);if(i<2)arrow(bx+331,top+116,14);line(bx,top+191,bx+326*p,top+191,C.green,4)}txt('模型结合音素与风格条件，预测时长、音高等，再解码。',ix,top+219,24);txt('过程图解 · 非运行结果',ix,top+262,20,C.orange);}
 if(s===3){txt('浏览器合成教学示意',ix,top-10,26,C.green,600);pill('非 Kokoro 实测',x+w-242,y+33,210,false,20);const wy=top+136;line(ix,wy,x+w-32,wy,C.pale,2);let change=ease((t-38)/55);let cycles=lerp(3,6,change);ctx.beginPath();for(let j=0;j<=w-64;j++){let q=j/(w-64);let yy=wy+Math.sin(q*Math.PI*2*cycles-t*.04)*(47+8*Math.sin(q*9))*.9;if(j===0)ctx.moveTo(ix+j,yy);else ctx.lineTo(ix+j,yy)}ctx.strokeStyle=C.green;ctx.lineWidth=3.5;ctx.stroke();txt('音高',ix,top+219,23);line(ix+90,top+236,x+w-40,top+236,C.pale,6);let hx=lerp(ix+175,x+w-130,change);ctx.beginPath();ctx.arc(hx,top+236,10,0,Math.PI*2);ctx.fillStyle=C.green;ctx.fill();txt('改变周期，观察波形变化',ix,top+269,23);}
 if(s===4){txt('来源与版本',ix,top-10,27,C.green,600);rr(ix,top+48,w-64,76,10,C.pale);txt('hexgrad / kokoro',ix+22,top+62,30,C.ink,600,'left','Segoe');txt('固定版本  dfb907a',ix+22,top+102,19,C.green,400,'left','Segoe');const rows=[['pipeline.py','文字 → 音素'],['model.py','时长、韵律 → 波形']];rows.forEach((v,i)=>{let yy=top+148+i*60;txt(v[0],ix+8,yy,26,C.ink,500,'left','Segoe');txt(v[1],ix+280,yy,24);line(ix,yy+43,ix+(w-64)*ease((t-i*45)/115),yy+43,C.green,1)});txt('官方来源可追溯 · 研究与实测分开记录',ix,top+280,21,C.green);}
 if(s===5){pill('验证计划',ix,top-7,136,true,22);pill('待实测',x+w-166,top-7,134,false,22);txt('数字能否读正确？',ix,top+63,42,C.ink,600);txt('固定模型、音色与设备',ix,top+132,25);rr(ix,top+192,w-64,84,10,C.pale);txt('记录',ix+22,top+210,21,C.green);txt('错读与遗漏',ix+124,top+210,29,C.ink,600);txt('结果：待填写',x+w-253,top+214,24,C.green);let u=ease((t-28)/120);line(ix+124,top+254,ix+124+178*u,top+254,C.green,3);}
 if(s===6){txt('理解原理  →  查看来源  →  小实验',x+w/2,y+60,21,C.green,400,'center');}
}
function draw(f){ctx.setTransform(1,0,0,1,0,0);ctx.globalAlpha=1;ctx.fillStyle=C.paper;ctx.fillRect(0,0,W,H);let {s,r}=mainRect(f);const t=f-starts[s];
 // A tiny optical push follows the reading path while the teaching waveform itself changes.
 let zoom=s===6?1+.035*(.4*clamp(t/150)+.6*ease(t/150)):1+.018*Math.sin(Math.PI*(f%180)/180);ctx.translate(640,360);ctx.scale(zoom,zoom);ctx.translate(-640,-360);
 if(s!==6){ctx.drawImage(logo,90,42,32,32);txt('GitHub 项目研究集',136,45,21,C.green,600);txt('KOKORO / 研究中',1190,49,17,C.green,400,'right','Segoe');}
 // Scene titles leave before the card arrives, avoiding simultaneous overprinted copy.
 if(s>0&&t<30){let p=ease(t/30);if(p<.5){ctx.save();ctx.globalAlpha=1-p*2;outer(s-1,ends[s-1]-starts[s-1]);ctx.restore()}else{ctx.save();ctx.globalAlpha=(p-.5)*2;outer(s,t);ctx.restore()}}else outer(s,t);
 if(s===0){ctx.save();ctx.translate(15,-10);ctx.rotate(.008);rr(r[0],r[1],r[2],r[3],18,C.pale);ctx.restore()}
 shadowRect(r);let [x,y,w,h]=r;
 ctx.save();ctx.beginPath();ctx.roundRect(x+1,y+1,w-2,h-2,18);ctx.clip();
 if(s>0&&t<30){let p=ease(t/30);let split=x+w*p;ctx.save();ctx.beginPath();ctx.rect(split,y,w*(1-p),h);ctx.clip();inner(s-1,ends[s-1]-starts[s-1],r);ctx.restore();ctx.save();ctx.beginPath();ctx.rect(x,y,w*p,h);ctx.clip();inner(s,t,r);ctx.restore();if(p>0&&p<1)line(split,y+8,split,y+h-8,C.pale,4);}else inner(s,t,r);ctx.restore();
 // The title is one continuous object, never separately replaced between scenes.
 const titleSize=s===6?27:39;let size=titleSize;if(s>0&&t<30)size=lerp(s-1===6?27:39,titleSize,ease(t/30));txt('Kokoro',x+32,y+29,size,C.ink,600,'left','Segoe');if(s!==6&&s!==3)txt('01',x+w-32,y+33,20,C.green,500,'right','Segoe');
 if(s>=5&&s!==6)txt('github.com/yydshly/1020_codex_project',640,640,25,C.green,400,'center','Segoe');
 if(s<5){let steps=['收藏','理解','原理','图解','来源','实验'];for(let i=0;i<5;i++){let xx=90+i*68;line(xx,655,xx+50,655,i<=s?C.green:C.pale,3)}txt(steps[s],1190,642,20,C.green,400,'right')}
}
async function render(out,from,to,blur=true){const ff=spawn('ffmpeg',['-hide_banner','-loglevel','error','-y','-f','rawvideo','-pixel_format','rgba','-video_size','1280x720','-framerate','60','-i','pipe:0','-an','-c:v','libx264','-preset','fast','-crf','18','-pix_fmt','yuv420p','-movflags','+faststart',out],{stdio:['pipe','inherit','inherit']});for(let f=from;f<to;f++){let moving=starts.some(b=>b>0&&f>=b&&f<b+30);if(blur&&moving){ac.setTransform(1,0,0,1,0,0);ac.clearRect(0,0,W,H);for(let j=0;j<3;j++){draw(f+j/3);ac.globalAlpha=1/3;ac.drawImage(canvas,0,0)}ac.globalAlpha=1;let b=ac.getImageData(0,0,W,H).data;if(!ff.stdin.write(b))await once(ff.stdin,'drain')}else{draw(f);if(!ff.stdin.write(ctx.getImageData(0,0,W,H).data))await once(ff.stdin,'drain')}if(f%120===0)console.log(`frame ${f}/${to}`)}ff.stdin.end();const [code]=await once(ff,'exit');if(code)throw new Error(`ffmpeg ${code}`)}
const mode=process.argv[2]||'stills';fs.mkdirSync('frames',{recursive:true});if(mode==='stills'){for(const f of [0,60,150,210,270,330,390,450,510,570,630,690,750,810,870,930,990,1065,1110,1199]){draw(f);fs.writeFileSync(`frames/frame-${String(f).padStart(4,'0')}.png`,canvas.toBuffer('image/png'))}}
if(mode==='test')await render('test-4s.mp4',0,240);
if(mode==='full')await render('video.mp4',0,1200);
if(mode==='frame'){const f=Number(process.argv[3]);draw(f);fs.writeFileSync(`frame-${f}.png`,canvas.toBuffer('image/png'))}
