from pathlib import Path
p=Path('render.mjs');s=p.read_text(encoding='utf8')
s=s.replace("const clamp=x=>", "const endRects=[[600,142,590,432],[260,156,930,446],[74,180,1132,414],[430,174,760,416],[292,164,898,436],[90,174,1100,424],[360,492,560,124]];\nconst clamp=x=>")
a=s.index('function mainRect(f)');b=s.index('function outer(s,t)',a)
s=s[:a]+'''function mainRect(f){let s=0;for(let i=1;i<starts.length;i++)if(f>=starts[i])s=i;let t=f-starts[s],r;if(s>0&&t<30){let p=ease(t/30);r=rects[s].map((v,i)=>lerp(endRects[s-1][i],v,p))}else{let u=clamp((t-(s?30:0))/(ends[s]-starts[s]-(s?30:0)));let p=.3*u+.7*ease(u);r=rects[s].map((v,i)=>lerp(v,endRects[s][i],p))}return {s,r}}\n''' +s[b:]
s=s.replace("txt('进入研究 →',ix,top+261,23,C.green,600);", "pill(t<60?'进入研究 →':'打开研究条目',ix,top+254,210,t>=60,21);let cp=ease(t/60);cursor(lerp(x+w-54,ix+160,cp),lerp(y+h-45,top+278,cp),t>=60&&t<78?(t-60)/18:0);")
s=s.replace("ease((t-i*28)/38)","ease((t-i*42)/90)")
s=s.replace("txt('深入拆解 · 本机效果待验证',ix,top+278,21,C.green);", "txt(t<100?'深入拆解 · 本机效果待验证':'原理入口：发音处理 → 时长与韵律 → 波形解码',ix,top+278,21,C.green);")
s=s.replace("ease((t-i*20)/50)","ease((t-i*45)/115)")
s=s.replace("let u=ease((t-60)/42)","let u=ease((t-28)/120)")
p.write_text(s,encoding='utf8')
