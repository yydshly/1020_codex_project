import json, pathlib, re, wave, math
import numpy as np
P=pathlib.Path(__file__).parent
fps=60; sr=48000; duration=20; n=sr*duration
starts=[0,180,360,540,720,900,1050]
events=[{'frame':60,'type':'open-research','beat':2},{'frame':270,'type':'principles-result','beat':9}]+[{'frame':x,'type':'panel-transition','beat':x//30} for x in starts[1:]]+ [{'frame':240,'type':'select-principles','beat':8},{'frame':420,'type':'phonemes','beat':14},{'frame':480,'type':'decode','beat':16},{'frame':600,'type':'teaching-control','beat':20},{'frame':780,'type':'open-source','beat':26},{'frame':960,'type':'experiment-question','beat':32}]
timing={'fps':fps,'frames':1200,'bpm':120,'beat_frames':list(range(0,1200,30)),'scene_start_frames':starts,'climax_frame':900,'voice':None,'events':events,'alignment':'All event starts and section boundaries are exact sample/frame multiples at 120 BPM.'}
(P/'timing.json').write_text(json.dumps(timing,ensure_ascii=False,indent=2),encoding='utf8')
rng=np.random.default_rng(20261023)
music=np.zeros((n,2),np.float64); sfx=np.zeros_like(music)
def add(buf,start,dur,freq,amp,kind='pluck',pan=0):
    a=int(start*sr); m=min(int(dur*sr),n-a)
    if m<=0:return
    t=np.arange(m)/sr
    if kind=='pad':
        env=np.minimum(1,t/.12)*np.minimum(1,(dur-t)/.35); sig=(np.sin(2*np.pi*freq*t)+.18*np.sin(2*np.pi*freq*2*t))*env
    elif kind=='bass':
        env=np.minimum(1,t/.012)*np.exp(-t*3); sig=(np.sin(2*np.pi*freq*t)+.2*np.sin(2*np.pi*freq*2*t))*env
    else:
        env=np.minimum(1,t/.006)*np.exp(-t*5.4)*np.minimum(1,(dur-t)/.03);sig=(np.sin(2*np.pi*freq*t)+.25*np.sin(2*np.pi*freq*2*t)+.07*np.sin(2*np.pi*freq*3*t))*env
    buf[a:a+m,0]+=sig*amp*math.sqrt((1-pan)/2);buf[a:a+m,1]+=sig*amp*math.sqrt((1+pan)/2)
def hz(midi):return 440*2**((midi-69)/12)
chords=[[50,57,62,65],[46,53,58,62],[53,60,65,69],[48,55,60,64],[50,57,62,65]]
for bar in range(10):
    chord=chords[(bar//2)%5]
    for j,midi in enumerate(chord):add(music,bar*2,2.65,hz(midi),.024,'pad',(j-1.5)/3)
    for k in range(4):add(music,bar*2+k*.5,.65,hz(chord[0]-12),.12,'bass')
    pattern=[0,2,1,3,2,1,3,2]
    for k,v in enumerate(pattern):add(music,bar*2+k*.25,1.1,hz(chord[v]+12),.047 if k%2==0 else .027,'pluck',(-.32 if k%2==0 else .32))
    for k in range(4):
        a=int((bar*2+k*.5)*sr);m=min(5000,n-a);t=np.arange(m)/sr
        noise=rng.normal(0,1,m); noise=np.concatenate(([0],np.diff(noise)));sig=noise*np.exp(-t*72)*.008
        music[a:a+m,0]+=sig;music[a:a+m,1]+=sig
for ev in events:
    st=ev['frame']/fps
    if ev['type']=='panel-transition':
        a=int(st*sr);m=min(int(.22*sr),n-a);t=np.arange(m)/sr;noise=rng.normal(0,1,m);noise=np.convolve(noise,np.ones(7)/7,mode='same');env=np.sin(np.pi*np.arange(m)/m)**2
        sfx[a:a+m,0]+=noise*env*.018;sfx[a:a+m,1]+=noise*env*.018
    else:add(sfx,st,.18,880,.024,'pluck',0)
# long-form cadence with a gentle tail, never voices or reference audio
fade=np.minimum(1,np.arange(n)/(.03*sr))*np.minimum(1,(n-np.arange(n))/(.35*sr));music*=fade[:,None];sfx*=fade[:,None]
def save(name,data):
    with wave.open(str(P/name),'wb') as w:w.setnchannels(2);w.setsampwidth(2);w.setframerate(sr);w.writeframes(np.clip(data*32767,-32768,32767).astype('<i2').tobytes())
save('music-raw.wav',music);save('sfx-raw.wav',sfx);save('mix-raw.wav',music+sfx)
report={'music_rms_dbfs':float(20*np.log10(np.sqrt(np.mean(music**2)))),'sfx_rms_dbfs':float(20*np.log10(np.sqrt(np.mean(sfx**2)))),'source':'Original deterministic additive synthesis, seed 20261023','sample_rate':sr,'duration':20,'subjective_listening':'unverified'}
(P/'audio-source.json').write_text(json.dumps(report,indent=2),encoding='utf8')
source=(P/'../shared/product/web/data.js').read_text(encoding='utf8');data=json.loads(source[source.index('{'):].rstrip().rstrip(';'));k=data['tools'][0]
facts={'frozen_sources':['../shared/product/web/data.js','../shared/product/web/app.js','../shared/product/web/styles.css','../shared/product/notes/07-experiments.md','../shared/product/README.md','../shared/captures/source-favicon.svg'],'claims':[{'screen':'Kokoro / 一段文字，怎样变成声音？','quote':k['headline'],'url':k['evidence']['url']},{'screen':'文稿 + 语言 + 音色 / 语音波形','quote':k['input']+' → '+k['output'],'url':k['evidence']['readme_url']},{'screen':'文字→音素→时长与韵律→波形解码','quote':k['mechanism'],'details':k['stages'],'url':k['evidence']['inspected_files'][2]['url']},{'screen':'来源与版本 / pipeline.py / model.py / dfb907a','quote':k['evidence'],'url':k['evidence']['url']},{'screen':'数字能否读正确？/ 错读与遗漏 / 待实测','quote':k['experiment'],'url':'../shared/product/notes/07-experiments.md'},{'screen':'声音基础 / 浏览器合成教学示意 / 非 Kokoro 实测','quote':'可调短音由浏览器合成。两者均为教学材料，不是 Kokoro 的效果测试。','url':'../shared/product/web/kokoro-learning.js:28'},{'screen':'GitHub 项目研究集 / github.com/yydshly/1020_codex_project','quote':'共同任务指定的产品名与落版网址','url':'../shared/brief.md'},{'screen':'收藏之后，下一步？/ 让收藏，成为理解。/ 每一步，都有来源。/ 用小实验，继续研究。','quote':'原创编辑性提问与导航性文案，不是功能效果或用户数据声明','url':'../shared/brief.md'}], 'disclosures':['All UI is code reconstruction from frozen real product; camera layouts simplified for legibility.','All waveform values are teaching illustration, not Kokoro model execution.','No model installed or tested; experiment stays pending.']}
(P/'facts.json').write_text(json.dumps(facts,ensure_ascii=False,indent=2),encoding='utf8')
print(json.dumps(report))
