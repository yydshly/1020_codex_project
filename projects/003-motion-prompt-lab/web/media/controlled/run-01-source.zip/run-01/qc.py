import json,re,pathlib,subprocess
import numpy as np
from PIL import Image
P=pathlib.Path(__file__).parent
def lum(h):
 c=[int(h[i:i+2],16)/255 for i in (1,3,5)];c=[x/12.92 if x<=.04045 else ((x+.055)/1.055)**2.4 for x in c];return .2126*c[0]+.7152*c[1]+.0722*c[2]
def ratio(a,b):
 x,y=sorted([lum(a),lum(b)]);return (y+.05)/(x+.05)
pairs=[['ink/paper','#263b34','#f6f5f0'],['green/paper','#255746','#f6f5f0'],['white/green','#fffefa','#255746'],['ink/pale','#263b34','#e7ede3'],['green/pale','#255746','#e7ede3'],['orange/white','#ac573b','#fffefa']]
contrast=[{'pair':n,'ratio':round(ratio(a,b),3)} for n,a,b in pairs]
bounds=[]
for p in sorted((P/'qc-samples').glob('*.png')):
 a=np.array(Image.open(p).convert('RGB'));mask=np.zeros(a.shape[:2],bool)
 for color in [(38,59,52),(37,87,70),(172,87,59)]: mask|=(np.max(np.abs(a.astype(int)-np.array(color)),axis=2)<9)
 yy,xx=np.where(mask)
 if len(xx):bounds.append({'file':p.name,'left':int(xx.min()),'top':int(yy.min()),'right':int(1279-xx.max()),'bottom':int(719-yy.max())})
(P/'contrast.json').write_text(json.dumps(contrast,indent=2));(P/'safe-margins.json').write_text(json.dumps({'method':'Dark brand-color pixels measured in decoded 5fps frames; this is bounding evidence, not OCR or semantic overlap certification.','frames':bounds},indent=2))
print('contrast_min',min(x['ratio'] for x in contrast));print('margin_min', min(min(v[k] for k in ['left','top','right','bottom']) for v in bounds) if bounds else None)
