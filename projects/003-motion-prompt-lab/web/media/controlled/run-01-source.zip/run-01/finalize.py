import json,pathlib,wave,numpy as np,hashlib,datetime
p=pathlib.Path('.')
def wav(n):
 with wave.open(n,'rb') as f:return np.frombuffer(f.readframes(f.getnframes()),dtype='<i2').astype(float).reshape(-1,2)/32768
m=wav('music-raw.wav');s=wav('sfx-raw.wav');tim=json.loads((p/'timing.json').read_text(encoding='utf8'));ev=[]
for e in tim['events']:
 a=int(e['frame']/60*48000);b=min(len(m),a+int(.22*48000));mr=np.sqrt(np.mean(m[a:b]**2));ss=np.sqrt(np.mean(s[a:b]**2));ev.append({'frame':e['frame'],'sfx_below_music_db':round(float(20*np.log10(mr/max(ss,1e-12))),2),'design_alignment_frames':0})
(p/'event-audio-check.json').write_text(json.dumps({'method':'Per-event 220ms RMS comparison of pre-mix stems; normalization applies shared gain. Event sample starts are integer frame multiples. Musical grid constructed at 120BPM; no human listening claim.','events':ev},indent=2))
quality={'specification':{'width':1280,'height':720,'fps':'60/1','duration_seconds':20,'decoded_frames':1200},'audio':{'integrated_LUFS':-14.08,'true_peak_dBTP':-1.60,'voice':False,'sfx_below_music_per_event_min_dB':min(e['sfx_below_music_db'] for e in ev),'subjective_listening':'unverified'},'freeze':{'filter':'freezedetect=n=-50dB:d=0.5','detected_segments':0,'note':'No >=0.5s segments detected; does not certify absence of all brief static intervals or semantic stagnation.'},'contrast_min':4.978,'sampled_brand_pixel_margin_min':37,'evidence':['probe-final.json','loudness-final.txt','freeze-final.txt','contrast.json','safe-margins.json','event-audio-check.json'],'subjective_reference_parity':'not established','full_reviewer':'pending','known_limitations':['Earlier full intermediate versions did not each get their own complete independent review.','Several scene reviews used limited stills instead of full 0.2s sampling.','Motion is planar product UI; reference-level subjective craft not established.','Playback/listening subjective check unverified.']}
(p/'quality-check.json').write_text(json.dumps(quality,ensure_ascii=False,indent=2),encoding='utf8')
(p/'output.sha256').write_text(hashlib.sha256((p/'output.mp4').read_bytes()).hexdigest()+'  output.mp4\n')
print('min sfx below music',min(e['sfx_below_music_db'] for e in ev))
