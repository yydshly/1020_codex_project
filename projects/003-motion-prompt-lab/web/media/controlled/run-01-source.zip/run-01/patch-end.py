from pathlib import Path
p=Path('render.mjs');s=p.read_text(encoding='utf8').replace('let zoom=1+.018*Math.sin(Math.PI*(f%180)/180);', 'let zoom=s===6?1+.035*(.4*clamp(t/150)+.6*ease(t/150)):1+.018*Math.sin(Math.PI*(f%180)/180);');p.write_text(s,encoding='utf8')
