from pathlib import Path
p=Path('render.mjs');s=p.read_text(encoding='utf8');s=s.replace("ctx.font=`${weight} ${size}px ${family}`", "if(/[\\u4e00-\\u9fff]/.test(s))family='YaHei';ctx.font=`${weight} ${size}px ${family}`")
s=s.replace("top+234,24", "top+219,24").replace("top+278,20,C.orange", "top+262,20,C.orange")
s=s.replace("if(s!==6)txt('01'", "if(s!==6&&s!==3)txt('01'")
s=s.replace("1+.008*Math.sin(Math.PI*(f%180)/180)","1+.018*Math.sin(Math.PI*(f%180)/180)")
p.write_text(s,encoding='utf8')
