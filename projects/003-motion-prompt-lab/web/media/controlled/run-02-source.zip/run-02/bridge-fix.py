from pathlib import Path
p=Path(__file__).with_name('render.cjs');s=p.read_text(encoding='utf8')
bridge=r"""
function bridges(t){
function morph(start,end,from,to,label){if(t<start||t>end)return;const p=tween(t,start,end),a=Math.sin(Math.PI*p);alpha(a,()=>{let x=mix(from[0],to[0],p),y=mix(from[1],to[1],p),w=mix(from[2],to[2],p),h=mix(from[3],to[3],p);shadow(()=>box(x,y,w,h,13,C.pale,C.line),12,.045);line(x+16,y+12,x+16,y+h-12,C.orange,3);if(label&&p>.12&&p<.83)alpha(Math.sin(Math.PI*clamp((p-.12)/.71)),()=>txt(label,x+30,y+h/2+9,25,C.green,500));});}
for(let i=0;i<3;i++)morph(4.6,5.4,[621,461,149,44],[96+i*366,280,326,245],['文字转音素','预测时长与韵律','解码为波形'][i]);
morph(8.6,9.4,[96,280,326,245],[96,365,1062,80],'文字转音素');
morph(8.6,9.4,[462,280,326,245],[96,450,1062,80],'时长、韵律与波形');
morph(12.1,12.9,[96,269,1062,303],[618,277,540,280],'Kokoro / 研究记录');
morph(16.1,16.9,[618,277,540,280],[604,282,72,72],'');
}
"""
s=s.replace('function frame(t){',bridge+'\nfunction frame(t){')
s=s.replace('experiment(t);ending(t);let keys','experiment(t);ending(t);bridges(t);let keys')
s=s.replace("txt('Kokoro / 底层原理',1165,218,17", "txt('Kokoro / 原理教学示意',1165,218,17")
p.write_text(s,encoding='utf8')
