from pathlib import Path
p=Path(__file__).with_name('render.cjs');s=p.read_text(encoding='utf8')
s=s.replace("tag('六个 AI 内容工具 · 研究中',68,458,278)","tag('GitHub 项目研究集 · 六个 AI 工具',68,458,367)")
s=s.replace("txt('专有名词',126,391,40,C.white,600);txt('与数字',126,446,40,C.white,600);txt('它能否正确、清楚地读出来？',126,517,22,C.white)","txt('测试文本（示例）',126,365,18,'#dde8dd');txt('Kokoro，编号 2026。',126,423,29,C.white,600);txt('检查专名与数字的读法',126,487,25,C.white);txt('它能否正确、清楚地读出来？',126,527,20,'#dde8dd')")
s=s.replace("frame(n/60);const buf=Buffer.from(g.getImageData(0,0,W,H).data.buffer);", "const time=n/60;const fast=[3,5,9,12.5,16.5].some(x=>Math.abs(time-x)<.45);if(fast){const acc=createCanvas(W,H),ac=acc.getContext('2d');for(let sub=0;sub<3;sub++){frame(Math.max(0,time+(sub-1)/240));ac.globalAlpha=1/(sub+1);ac.drawImage(c,0,0);}g.globalAlpha=1;g.drawImage(acc,0,0);}else frame(time);const buf=Buffer.from(g.getImageData(0,0,W,H).data.buffer);")
p.write_text(s,encoding='utf8')
