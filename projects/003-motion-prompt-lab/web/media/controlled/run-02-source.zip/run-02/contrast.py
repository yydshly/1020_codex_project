import json,math
from pathlib import Path
r=Path(__file__).resolve().parent
colors={'paper':'f6f5f0','white':'fffefa','ink':'263b34','muted':'526057','green':'255746','deep':'163f33','pale':'e7ede3','orange':'ac573b','sand':'f2e8da','light':'dde8dd','brown':'80412f'}
def lum(h):
 a=[int(h[i:i+2],16)/255 for i in (0,2,4)];a=[v/12.92 if v<=.04045 else ((v+.055)/1.055)**2.4 for v in a];return sum(v*w for v,w in zip(a,[.2126,.7152,.0722]))
pairs=[('ink','paper'),('ink','white'),('ink','pale'),('muted','paper'),('muted','white'),('muted','pale'),('green','paper'),('green','white'),('green','pale'),('orange','paper'),('orange','white'),('white','deep'),('light','deep'),('brown','sand'),('white','green')]
res=[]
for fg,bg in pairs:
 a,b=lum(colors[fg]),lum(colors[bg]);ratio=(max(a,b)+.05)/(min(a,b)+.05);res.append({'foreground':fg,'background':bg,'ratio':round(ratio,3),'passes_4_5':ratio>=4.5})
(r/'evidence/contrast.json').write_text(json.dumps({'method':'WCAG sRGB relative luminance; settled text colors, excluding intentional transitional alpha and antialias edge pixels','pairs':res,'minimum':min(x['ratio'] for x in res)},indent=2),encoding='utf8')
print(json.dumps(res))
