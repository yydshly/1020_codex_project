from pathlib import Path
p=Path(__file__).with_name('render.cjs');s=p.read_text(encoding='utf-8-sig')
s=s.replace("12,C.muted,500,'left','Segoe'","12,C.muted,500,'left','Yahei'")
s=s.replace('let a=1-move;','let a=1-tween(t,2.45,2.95);')
s=s.replace('tween(t,2.65,3.35)*(1-tween(t,4.55,5.2))','tween(t,2.95,3.35)*(1-tween(t,4.55,4.85))')
s=s.replace('tween(t,4.55,5.2)*(1-tween(t,8.6,9.3))','tween(t,4.85,5.2)*(1-tween(t,8.6,8.95))')
s=s.replace('tween(t,8.6,9.3)*(1-tween(t,12.1,12.8))','tween(t,8.95,9.3)*(1-tween(t,12.1,12.45))')
s=s.replace('tween(t,12.1,12.8)*(1-tween(t,16.1,16.9))','tween(t,12.45,12.8)*(1-tween(t,16.1,16.5))')
s=s.replace('let p=tween(t,16.1,16.9);','let p=tween(t,16.5,16.9);')
s=s.replace('let drift=12*Math.sin(Math.min(t,2.5)*.55);','let drift=-26*ease(t/2.5);')
s=s.replace("let keys=[[0,1174,153],[2.45,1174,153],[3.35,272,168],[4.55,272,168],[5.2,1134,168],[8.6,1134,168],[9.3,1134,168],[12.1,1134,168],[12.8,1134,168],[16.1,1134,168],[16.9,1188,65],[20,1188,65]];", "let keys=[[0,1174,153],[2.45,1148,161],[3.35,763,460],[4.55,763,460],[5.2,398,253],[6.35,398,253],[6.9,764,253],[7.5,764,253],[8.1,1130,253],[8.6,1130,253],[9.3,112,270],[10,112,270],[10.5,106,367],[11,106,367],[11.5,106,454],[12.1,106,454],[12.8,112,277],[13.5,112,277],[14.1,1138,277],[16.1,1138,277],[16.9,1188,65],[20,1188,65]];")
# Proof links are visited one by one, reinforcing correspondence rather than decorative drift.
s=s.replace("txt('↗',1099,y+28,24,C.green,400,'right')", "txt('↗',1099,y+28,24,C.green,400,'right');let trace=tween(t,9.5+i*.9,10.3+i*.9);line(580,y+40,580+520*trace,y+40,C.orange,2)")
# Final route is written once and assembles the original source favicon's three lines.
s=s.replace("icon(604,282-drift,72);", "icon(604,282-drift,72);let route=tween(t,17,19.65);line(382,240-drift,382+516*route,240-drift,C.orange,2);dot(382+516*route,240-drift,4,C.orange);")
# Stable sample becomes a filled-in research question, never a claimed model result.
s=s.replace("txt('错读记录',646+dx,399,28,C.ink);", "txt('错读记录',646+dx,399,28,C.ink);let focus=tween(t,13.8,15.4);line(646+dx,417,646+dx+145*focus,417,C.orange,2);")
# Mid-transition fast moving bookmark has restrained temporal trails.
s=s.replace('bookmark(bx,by,38);', "for(let trail=3;trail>=1;trail--){let qt=tween(t-trail/180,keys[k][0],keys[k+1][0]);let tx=mix(keys[k][1],keys[k+1][1],qt),ty=mix(keys[k][2],keys[k+1][2],qt);if(Math.hypot(tx-bx,ty-by)>3)alpha(.045,()=>bookmark(tx,ty,38));}bookmark(bx,by,38);")
p.write_text(s,encoding='utf8')
print('revision 2')
