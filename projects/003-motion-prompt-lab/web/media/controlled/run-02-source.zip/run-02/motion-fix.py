from pathlib import Path
p=Path(__file__).with_name('render.cjs');s=p.read_text(encoding='utf8')
s=s.replace('let drift=-26*ease(t/2.5);','let drift=-60*clamp(t/2.6);')
s=s.replace('[2.6,1148,161]','[2.6,1114,171]')
s=s.replace('function frame(t){backdrop(t);let f;',"function frame(t){backdrop(t);g.save();let camera=1;if(t>=3.4&&t<5.4){camera=1+.035*(t<4.6?clamp((t-3.4)/1.2):1-tween(t,4.6,5.4));}if(t>=16.5){camera=mix(.98,1.04,clamp((t-16.5)/3.5));}g.translate(640,360);g.scale(camera,camera);g.translate(-640,-360);let f;")
s=s.replace("txt('持续研究中',1117,149,13,C.muted,400,'right');} }","txt('持续研究中',1117,149,13,C.muted,400,'right');}g.restore(); }")
p.write_text(s,encoding='utf8')
