import wave, math, struct
import numpy as np
from pathlib import Path
ROOT=Path(__file__).resolve().parent
SR=48000; N=SR*20
music=np.zeros((N,2),dtype=np.float64); sfx=np.zeros((N,2),dtype=np.float64)
rng=np.random.default_rng(230102)
def add(buf, start, signal, pan=0):
 i=int(round(start*SR)); n=min(len(signal),N-i)
 if n<=0:return
 buf[i:i+n,0]+=signal[:n]*math.sqrt((1-pan)/2);buf[i:i+n,1]+=signal[:n]*math.sqrt((1+pan)/2)
def tone(freq,dur,kind='pluck'):
 t=np.arange(int(SR*dur))/SR
 if kind=='pluck':
  env=(1-np.exp(-t*400))*np.exp(-t*3.3)
  return (.75*np.sin(2*np.pi*freq*t)+.18*np.sin(2*np.pi*2*freq*t)*np.exp(-t*5)+.07*np.sin(2*np.pi*3*freq*t))*env
 if kind=='bass':return np.sin(2*np.pi*freq*t)*(1-np.exp(-t*60))*np.exp(-t*2.5)
 env=np.sin(np.pi*np.minimum(t/dur,1))**.8
 return (np.sin(2*np.pi*freq*t)+.3*np.sin(2*np.pi*freq*2.002*t))*.5*env
chords=[[146.832,174.614,220,293.665],[130.813,164.814,195.998,261.626],[116.541,146.832,174.614,233.082],[130.813,164.814,195.998,261.626],[146.832,174.614,220,293.665]]
# 120 BPM: sections and every interaction sit exactly on the 0.5 s grid.
for bar in range(10):
 chord=chords[bar//2]
 for f in chord:add(music,bar*2,tone(f,2.4,'pad')*.095,pan=(f/chord[-1]-.75)*.4)
 for beat in range(4):
  tm=bar*2+beat*.5
  add(music,tm,tone(chord[0]/2,.47,'bass')*.24)
  tt=np.arange(int(.16*SR))/SR
  kick=np.sin(2*np.pi*(48*tt+45*(1-np.exp(-tt*24))/24))*np.exp(-tt*30)
  if beat%2==0:add(music,tm,kick*.27)
  hat=rng.normal(0,1,int(.045*SR));hat=np.diff(hat,prepend=0)*np.exp(-np.arange(len(hat))/SR*110)*.015
  add(music,tm+.25,hat,pan=.3)
  if beat%2==1:
   tick=rng.normal(0,1,int(.08*SR))*np.exp(-np.arange(int(.08*SR))/SR*65)*.035
   add(music,tm,tick,pan=-.15)
 notes=[0,2,1,3,2,1,3,2]
 for k,idx in enumerate(notes):
  if bar==9 and k>3:continue
  add(music,bar*2+k*.25,tone(chord[idx]*(2 if k%3 else 1),1.0)*.105,pan=(-.35 if k%2 else .35))
for tm in [0,3,5,9,12.5,16.5]:
 tt=np.arange(int(.18*SR))/SR
 click=(np.sin(2*np.pi*(900*tt-1200*tt*tt))*np.exp(-tt*35))*.04
 add(sfx,tm,click,pan=.15)
# deterministic, original transition foley: low-level filtered noise swell preceding the beat.
for tm in [3,5,9,12.5,16.5]:
 tt=np.arange(int(.25*SR))/SR
 noise=rng.normal(0,1,len(tt));noise=np.convolve(noise,np.ones(14)/14,mode='same')
 sig=noise*np.sin(np.pi*tt/.25)**2*.025
 add(sfx,tm-.25,sig,pan=-.25)
fade=np.minimum(np.arange(N)/SR/.03,1)*np.minimum((N-1-np.arange(N))/SR/.35,1)
music*=fade[:,None];sfx*=fade[:,None]
def save(name,v):
 with wave.open(str(ROOT/name),'wb') as f:
  f.setnchannels(2);f.setsampwidth(3);f.setframerate(SR)
  q=np.rint(np.clip(v,-.999,.999)*(2**23-1)).astype(np.int32).reshape(-1)
  b=np.empty((len(q),3),np.uint8);b[:,0]=q&255;b[:,1]=(q>>8)&255;b[:,2]=(q>>16)&255;f.writeframes(b.tobytes())
save('music-original.wav',music);save('sfx-original.wav',sfx);save('mix-original.wav',music+sfx)
import json
rms=lambda a:float(np.sqrt(np.mean(a*a)))
(ROOT/'evidence/audio-design.json').write_text(json.dumps({'bpm':120,'beat_seconds':.5,'event_seconds':[0,3,5,9,12.5,16.5],'event_frame_offsets':[0,0,0,0,0,0],'music_rms_dbfs':20*math.log10(rms(music)),'sfx_rms_dbfs':20*math.log10(rms(sfx)),'sfx_below_music_db':20*math.log10(rms(music)/rms(sfx)),'seed':230102,'voice':False,'subjective_listening':'unverified'},indent=2),encoding='utf8')
print('original music and sfx written')
