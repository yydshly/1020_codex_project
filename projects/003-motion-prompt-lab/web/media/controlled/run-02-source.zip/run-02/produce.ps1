$ErrorActionPreference='Stop'
$RunRoot=$PSScriptRoot
python "$RunRoot/audio.py"
ffmpeg -y -hide_banner -i "$RunRoot/mix-original.wav" -af 'loudnorm=I=-14:TP=-1.5:LRA=9:print_format=json' -f null NUL 2> "$RunRoot/evidence/mix-pass1.log"
ffmpeg -y -hide_banner -i "$RunRoot/music-original.wav" -af 'loudnorm=I=-14:TP=-1.5:LRA=9:print_format=json' -f null NUL 2> "$RunRoot/evidence/music-pass1.log"
python "$RunRoot/master.py"
node "$RunRoot/render.cjs" render
ffmpeg -y -hide_banner -loglevel error -i "$RunRoot/video-silent.mp4" -i "$RunRoot/mix-master.wav" -map 0:v:0 -map 1:a:0 -c:v copy -c:a aac -b:a 320k -ar 48000 -t 20 -movflags +faststart "$RunRoot/output.mp4"
ffmpeg -y -hide_banner -loglevel error -i "$RunRoot/video-silent.mp4" -i "$RunRoot/music-only.wav" -map 0:v:0 -map 1:a:0 -c:v copy -c:a aac -b:a 320k -ar 48000 -t 20 -movflags +faststart "$RunRoot/output-music-only.mp4"
