import json,re,subprocess
from pathlib import Path
r=Path(__file__).resolve().parent
for stem,inp,out in [('mix','mix-original.wav','mix-master.wav'),('music','music-original.wav','music-only.wav')]:
 text=(r/'evidence'/f'{stem}-pass1.log').read_text(encoding='utf-16' if (r/'evidence'/f'{stem}-pass1.log').read_bytes()[:2]==b'\xff\xfe' else 'utf-8-sig')
 m=json.loads(re.search(r'\{[^{}]+\}',text).group())
 f=f"loudnorm=I=-14:TP=-1.5:LRA=9:measured_I={m['input_i']}:measured_TP={m['input_tp']}:measured_LRA={m['input_lra']}:measured_thresh={m['input_thresh']}:offset={m['target_offset']}:linear=true:print_format=json"
 subprocess.run(['ffmpeg','-y','-hide_banner','-loglevel','error','-i',str(r/inp),'-af',f,'-ar','48000','-c:a','pcm_s24le',str(r/out)],check=True)
print('masters ready')
